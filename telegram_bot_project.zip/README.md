# Telegram Bot (aiogram)

A Python Telegram bot using long polling and SQLite.

## Files

- `bot.py` — bot application
- `requirements.txt` — Python dependency list

## Configure environment variables

Set these in your hosting provider's **Environment Variables / Secrets** settings:

- `TELEGRAM_BOT_TOKEN` — token from Telegram's official `@BotFather`
- `ADMIN_ID` — main administrator's numeric Telegram ID; defaults to `8620613020`

Do not commit bot tokens or other secrets to GitHub.

## Run locally

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
```

Activate the environment, then install dependencies:

```bash
pip install -r requirements.txt
```

Set environment variables before starting the bot.

Linux/macOS:
```bash
export TELEGRAM_BOT_TOKEN="YOUR_BOT_TOKEN"
export ADMIN_ID="8620613020"
python bot.py
```

Windows PowerShell:
```powershell
$env:TELEGRAM_BOT_TOKEN="YOUR_BOT_TOKEN"
$env:ADMIN_ID="8620613020"
python bot.py
```

## Hosting

Use the start command:

```bash
python bot.py
```

Configure a persistent disk/volume for the `bot_data.db` file if your host's filesystem is ephemeral. Free hosting providers may sleep, restart, or change their terms, so 24/7 uptime is not guaranteed.

## Admin commands

The main admin is identified by `ADMIN_ID`.

- `/adminhelp` — show commands
- `/addadmin <telegram_id>` — main admin only; authorize an admin
- `/removeadmin <telegram_id>` — main admin only; revoke an admin (main admin cannot be removed)
- `/admins` — main admin only; list admin IDs
- `/stats` — admin-only counts
- `/user <telegram_id>` — admin-only view of a record
- `/delete_user <telegram_id>` — main admin only; delete a record
- `/privacy` — explain stored data
- `/delete_me` — let a user delete their own stored record
- `/cancel` — dismiss the current keyboard

There is no hard-coded shared password that grants administrator access. Admins must be explicitly authorized by the main admin.

## Privacy

The bot saves a Telegram numeric ID and profile fields after `/start`. Phone number and location are optional and stored only when the user explicitly shares their own contact or location. Contact cards for other people are rejected. Tell users what the data is used for, restrict database access, and delete records when no longer needed.
